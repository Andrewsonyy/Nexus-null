export type SignalStatus = 'available' | 'partial' | 'missing';

export type SystemStatus = {
  system: string;
  ai_engine: string;
  timestamp: string;
};

export type SignalsResponse = {
  signals: { name: string; status: SignalStatus }[];
};

export type EpistemicMetrics = {
  known_variables: number;
  known_unknowns: number;
  blind_spots: number;
  completeness: number;
  uncertainty: number;
  risk: number;
};

export type DecisionStatus = {
  status: 'allowed' | 'blocked';
  action: 'allow_attack_detection' | 'refuse_attack_detection';
  reason: string;
  confidence: number;
  threshold: number;
  missing_variables: string[];
  investigation_questions: string[];
  investigation_analysis: {
    answered_questions: number;
    total_questions: number;
    coverage: number;
    conclusive_answers: number;
    sufficient_for_prediction: boolean;
    risk_adjustment: number;
    insights: string[];
    unresolved_questions: string[];
  };
  threat_assessment: {
    classification: 'benign' | 'suspicious' | 'malicious';
    risk_level: 'low' | 'medium' | 'high';
    risk_score: number;
    confidence: number;
    reasons: string[];
  };
  final_prediction: {
    status: 'pending_investigation' | 'refused' | 'attack_likely' | 'no_attack_indicated' | 'suspicious_needs_review';
    label: string;
    risk_score: number;
    confidence: number;
    reason: string;
    method: 'deferred' | 'rule_based' | 'ml_fallback';
  };
};

export type BlindspotAnalysis = {
  observed: number;
  inferred_gaps: number;
  blind_spot_risks: number;
};

export type SystemLogEntry = {
  time: string;
  type: 'success' | 'warning' | 'error' | 'info' | 'status';
  message: string;
};

export type TelemetryRecord = {
  time: string;
  login_activity: string | number;
  cpu_usage: string | number;
  network_traffic: string | number;
  file_changes: string | number;
  user_behavior: string | number;
};

export type InvestigationAnswer = {
  question: string;
  answer: string;
};

export type ModelInfo = {
  loaded: boolean;
  path: string;
  checked_paths?: string[];
  model_type?: string;
  feature_count?: number;
  feature_names?: string[];
  error?: string;
};

export type ModelPrediction = {
  ok: true;
  status: 'attack_likely' | 'no_attack_indicated' | 'suspicious_needs_review';
  risk_score: number;
  predicted_label: number;
  attack_probability: number;
  expected_feature_count: number;
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8000';

async function getJSON<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error(`API request failed for ${path}: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

async function postJSON<T, B>(path: string, body: B): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error(`API request failed for ${path}: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

async function deleteJSON<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
  });
  if (!response.ok) {
    throw new Error(`API request failed for ${path}: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export const api = {
  systemStatus: () => getJSON<SystemStatus>('/api/system-status'),
  signals: () => getJSON<SignalsResponse>('/api/signals'),
  epistemicMetrics: () => getJSON<EpistemicMetrics>('/api/epistemic-metrics'),
  decisionStatus: () => getJSON<DecisionStatus>('/api/decision-status'),
  blindspotAnalysis: () => getJSON<BlindspotAnalysis>('/api/blindspot-analysis'),
  systemLogs: () => getJSON<SystemLogEntry[]>('/api/system-logs'),
  telemetry: () => getJSON<{ records: TelemetryRecord[] }>('/api/telemetry'),
  addTelemetry: (record: TelemetryRecord) => postJSON<{ status: string; records_count: number }, TelemetryRecord>('/api/telemetry', record),
  clearTelemetry: () =>
    deleteJSON<{
      status: string;
      records_count: number;
      cleared_telemetry_records: number;
      cleared_investigation_answers: number;
    }>('/api/telemetry'),
  investigationAnswers: () => getJSON<{ answers: Record<string, string> }>('/api/investigation-answers'),
  submitInvestigationAnswers: (answers: InvestigationAnswer[]) =>
    postJSON<{ status: string; saved_answers: number }, { answers: InvestigationAnswer[] }>('/api/investigation-answers', { answers }),
  clearInvestigationAnswers: () => deleteJSON<{ status: string }>('/api/investigation-answers'),
  modelInfo: () => getJSON<ModelInfo>('/api/model-info'),
  modelPredict: (features: Record<string, string | number>) =>
    postJSON<ModelPrediction, { features: Record<string, string | number> }>('/api/model-predict', { features }),
};
