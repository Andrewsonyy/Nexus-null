'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { api, type DecisionStatus, type InvestigationAnswer } from '@/lib/api';

const fallbackDecision: DecisionStatus = {
  status: 'blocked',
  action: 'refuse_attack_detection',
  reason: 'Insufficient telemetry for safe threat detection.',
  confidence: 0,
  threshold: 70,
  missing_variables: [],
  investigation_questions: [],
  investigation_analysis: {
    answered_questions: 0,
    total_questions: 0,
    coverage: 100,
    conclusive_answers: 0,
    sufficient_for_prediction: false,
    risk_adjustment: 0,
    insights: ['No investigation questions required.'],
    unresolved_questions: [],
  },
  threat_assessment: {
    classification: 'benign',
    risk_level: 'low',
    risk_score: 0,
    confidence: 0,
    reasons: ['No suspicious indicators detected from provided security fields'],
  },
  final_prediction: {
    status: 'pending_investigation',
    label: 'PENDING INVESTIGATION',
    risk_score: 0,
    confidence: 0,
    reason: 'Insufficient telemetry for safe threat detection.',
    method: 'deferred',
  },
};

export function InvestigationResponsePanel() {
  const [decision, setDecision] = useState<DecisionStatus>(fallbackDecision);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [statusText, setStatusText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [clearing, setClearing] = useState(false);
  const hasUnsavedLocalChanges = useRef(false);

  const normalizeDecision = (decisionData: Partial<DecisionStatus>): DecisionStatus => ({
    ...fallbackDecision,
    ...decisionData,
    investigation_analysis: decisionData.investigation_analysis ?? fallbackDecision.investigation_analysis,
    threat_assessment: decisionData.threat_assessment ?? fallbackDecision.threat_assessment,
    final_prediction: decisionData.final_prediction ?? fallbackDecision.final_prediction,
    missing_variables: decisionData.missing_variables ?? [],
    investigation_questions: decisionData.investigation_questions ?? [],
  });

  useEffect(() => {
    const load = async () => {
      try {
        const [decisionData, answerData] = await Promise.all([api.decisionStatus(), api.investigationAnswers()]);
        const normalizedDecision = normalizeDecision(decisionData);
        setDecision(normalizedDecision);

        setAnswers((prev) => {
          const nextAnswers: Record<string, string> = {};
          for (const question of normalizedDecision.investigation_questions) {
            const serverAnswer = answerData.answers[question] ?? '';
            const localAnswer = prev[question] ?? '';
            nextAnswers[question] = hasUnsavedLocalChanges.current ? localAnswer : serverAnswer;
          }
          return nextAnswers;
        });
      } catch {
        setDecision(fallbackDecision);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    const onUpdated = () => {
      void load();
    };
    window.addEventListener('telemetry-updated', onUpdated);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onUpdated);
    };
  }, []);

  const questionCount = decision.investigation_questions.length;
  const answeredCount = useMemo(
    () => Object.values(answers).filter((value) => value.trim().length > 0).length,
    [answers],
  );

  const setAnswer = (question: string, value: string) => {
    hasUnsavedLocalChanges.current = true;
    setAnswers((prev) => ({ ...prev, [question]: value }));
  };

  const suggestionOptions = (question: string): string[] => {
    const q = question.toLowerCase();
    const base = ['yes', 'no', 'unknown', 'not sure', 'pending'];

    if (q.includes('cpu')) {
      return ['95', '90', '85', '70', '55', '?', ...base];
    }
    if (q.includes('login')) {
      return ['50', '30', '20', '10', '5', '1', '?', ...base];
    }
    if (q.includes('network') || q.includes('outbound')) {
      return ['high', 'spike', 'anomalous', 'exfiltration_like', 'normal', '?', ...base];
    }
    if (q.includes('file')) {
      return ['modified', 'mass_modified', 'encrypted', 'deleted', 'normal', '?', ...base];
    }
    if (q.includes('privileged') || q.includes('admin') || q.includes('user')) {
      return ['privileged', 'abnormal_access', 'privilege_escalation', 'normal', '?', ...base];
    }
    return base;
  };

  const datalistIdFor = (question: string, index: number): string =>
    `investigation-answer-${index}-${question.replace(/[^a-zA-Z0-9]+/g, '-').toLowerCase()}`;

  const submitAnswers = async () => {
    const payload: InvestigationAnswer[] = decision.investigation_questions.map((question) => ({
      question,
      answer: answers[question] ?? '',
    }));

    setSubmitting(true);
    setStatusText('');
    try {
      await api.submitInvestigationAnswers(payload);
      hasUnsavedLocalChanges.current = false;
      setStatusText('Investigation answers saved. Final prediction updated.');
      window.dispatchEvent(new Event('telemetry-updated'));
    } catch {
      setStatusText('Failed to save investigation answers. Check backend.');
    } finally {
      setSubmitting(false);
    }
  };

  const clearAnswers = async () => {
    setClearing(true);
    setStatusText('');
    try {
      await api.clearInvestigationAnswers();
      hasUnsavedLocalChanges.current = false;
      const cleared: Record<string, string> = {};
      for (const question of decision.investigation_questions) {
        cleared[question] = '';
      }
      setAnswers(cleared);
      setStatusText('Investigation answers cleared.');
      window.dispatchEvent(new Event('telemetry-updated'));
    } catch {
      setStatusText('Failed to clear investigation answers. Check backend.');
    } finally {
      setClearing(false);
    }
  };

  return (
    <Card className="border-border bg-card/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <HelpCircle className="w-5 h-5 text-accent" />
          Investigation Answers and Final Prediction
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-xs text-muted-foreground">
          Questions answered: {answeredCount}/{questionCount} | Final: {decision.final_prediction.label}
        </div>

        {questionCount === 0 ? (
          <div className="text-sm text-green-500 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            No investigation questions pending.
          </div>
        ) : (
          <div className="space-y-3">
            {decision.investigation_questions.map((question, index) => (
              <div key={question} className="space-y-2">
                <div className="text-sm text-foreground">{question}</div>
                <Input
                  value={answers[question] ?? ''}
                  onChange={(e) => setAnswer(question, e.target.value)}
                  list={datalistIdFor(question, index)}
                  placeholder="Type or select answer (example: 93, high, yes, normal, unknown)"
                />
                <datalist id={datalistIdFor(question, index)}>
                  {suggestionOptions(question).map((option) => (
                    <option key={`${question}-${option}`} value={option} />
                  ))}
                </datalist>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3">
          <Button onClick={submitAnswers} disabled={submitting || questionCount === 0}>
            {submitting ? 'Saving...' : 'Save Answers and Recompute'}
          </Button>
          <Button variant="destructive" onClick={clearAnswers} disabled={clearing}>
            {clearing ? 'Clearing...' : 'Clear Answers'}
          </Button>
          {statusText ? <span className="text-xs text-muted-foreground">{statusText}</span> : null}
        </div>
      </CardContent>
    </Card>
  );
}
