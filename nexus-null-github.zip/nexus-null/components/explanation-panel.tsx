'use client';

import { useEffect, useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api, type DecisionStatus } from '@/lib/api';

const fallbackDecision: DecisionStatus = {
  status: 'blocked',
  action: 'refuse_attack_detection',
  reason: 'Insufficient telemetry for safe threat detection.',
  confidence: 0,
  threshold: 70,
  missing_variables: [],
  investigation_questions: [],
  investigation_analysis: {
    answered_questions: 0,
    total_questions: 0,
    coverage: 100,
    conclusive_answers: 0,
    sufficient_for_prediction: false,
    risk_adjustment: 0,
    insights: ['No investigation questions required.'],
    unresolved_questions: [],
  },
  threat_assessment: {
    classification: 'benign',
    risk_level: 'low',
    risk_score: 0,
    confidence: 0,
    reasons: ['No suspicious indicators detected from provided security fields.'],
  },
  final_prediction: {
    status: 'pending_investigation',
    label: 'PENDING INVESTIGATION',
    risk_score: 0,
    confidence: 0,
    reason: 'Insufficient telemetry for safe threat detection.',
    method: 'deferred',
  },
};

export function ExplanationPanel() {
  const [decision, setDecision] = useState<DecisionStatus>(fallbackDecision);

  useEffect(() => {
    const normalizeDecision = (decisionData: Partial<DecisionStatus>): DecisionStatus => ({
      ...fallbackDecision,
      ...decisionData,
      threat_assessment: decisionData.threat_assessment ?? fallbackDecision.threat_assessment,
      final_prediction: decisionData.final_prediction ?? fallbackDecision.final_prediction,
      investigation_analysis: decisionData.investigation_analysis ?? fallbackDecision.investigation_analysis,
      missing_variables: decisionData.missing_variables ?? [],
      investigation_questions: decisionData.investigation_questions ?? [],
    });

    const load = async () => {
      try {
        setDecision(normalizeDecision(await api.decisionStatus()));
      } catch {
        setDecision(fallbackDecision);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    const onTelemetryUpdate = () => {
      void load();
    };
    window.addEventListener('telemetry-updated', onTelemetryUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onTelemetryUpdate);
    };
  }, []);

  const decisionBlocked = decision.status === 'blocked';
  const missing = decision.missing_variables.join(', ') || 'None';
  const threat = decision.threat_assessment;
  const primaryThreatReason = threat.reasons[0] ?? 'No suspicious indicators detected from provided security fields.';

  return (
    <Card className="border-border bg-card/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <MessageSquare className="w-5 h-5 text-accent" />
          AI Reasoning Explanation
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="bg-secondary/40 rounded-lg border border-border p-4 space-y-2 font-mono text-sm">
          <div className="text-muted-foreground">
            <span className="text-accent">[SYSTEM]</span>{' '}
            {decisionBlocked ? 'Decision blocked.' : 'Decision allowed.'} {decision.reason}
          </div>
          <div className="text-muted-foreground">
            <span className="text-accent">[ANALYSIS]</span> Missing critical variables: {missing}
          </div>
          <div className="text-muted-foreground">
            <span className="text-accent">[THREAT]</span> {threat.classification.toUpperCase()} risk ({threat.risk_score}%): {primaryThreatReason}
          </div>
          <div className="text-muted-foreground">
            <span className="text-accent">[STATUS]</span> Confidence threshold check: {decision.confidence}% / {decision.threshold}%
          </div>
          <div className="text-muted-foreground">
            <span className="text-accent">[FINAL]</span> {decision.final_prediction.label} ({decision.final_prediction.risk_score}% risk /{' '}
            {decision.final_prediction.confidence}% confidence)
          </div>
          <div className="text-muted-foreground">
            <span className="text-accent">[ACTION]</span>{' '}
            {decision.investigation_questions.length > 0
              ? decision.investigation_questions.join(' | ')
              : 'No investigation question generated.'}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
