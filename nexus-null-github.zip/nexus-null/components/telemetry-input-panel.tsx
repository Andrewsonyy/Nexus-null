'use client';

import { useMemo, useState, type FormEvent } from 'react';
import { Send } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { api, type TelemetryRecord } from '@/lib/api';

function currentTimeHHMM(): string {
  const now = new Date();
  return now.toTimeString().slice(0, 5);
}

const loginOptions = ['1', '3', '5', '10', '20', '30', '50', '?'];
const cpuOptions = ['25', '40', '65', '80', '90', '95', '?'];
const networkOptions = ['normal', 'high', 'spike', 'anomalous', 'exfiltration_like', '?'];
const fileChangeOptions = ['normal', 'modified', 'mass_modified', 'encrypted', 'deleted', '?'];
const userBehaviorOptions = ['normal', 'anomalous', 'abnormal_access', 'privilege_escalation', 'impossible_travel', '?'];

export function TelemetryInputPanel() {
  const initialData = useMemo<TelemetryRecord>(
    () => ({
      time: currentTimeHHMM(),
      login_activity: '',
      cpu_usage: '',
      network_traffic: '',
      file_changes: '',
      user_behavior: '',
    }),
    [],
  );
  const [formData, setFormData] = useState<TelemetryRecord>(initialData);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  const onFieldChange = (key: keyof TelemetryRecord, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting(true);
    setStatusMessage('');
    try {
      await api.addTelemetry(formData);
      setStatusMessage('Telemetry record submitted.');
      setFormData({
        ...initialData,
        time: currentTimeHHMM(),
      });
      window.dispatchEvent(new Event('telemetry-updated'));
    } catch {
      setStatusMessage('Submission failed. Check backend availability.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const onClearTelemetry = async () => {
    setIsClearing(true);
    setStatusMessage('');
    try {
      const result = await api.clearTelemetry();
      setFormData({
        ...initialData,
        time: currentTimeHHMM(),
      });
      setStatusMessage(
        `Session cleared: ${result.cleared_telemetry_records} telemetry record(s), ${result.cleared_investigation_answers} investigation answer(s).`,
      );
      window.dispatchEvent(new Event('telemetry-updated'));
    } catch {
      setStatusMessage('Clear request failed. Check backend availability.');
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <Card className="border-border bg-card/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-foreground">Telemetry Input</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Input
            placeholder="time (HH:MM)"
            type="time"
            value={String(formData.time)}
            onChange={(e) => onFieldChange('time', e.target.value)}
            required
          />
          <Input
            placeholder="login_activity"
            value={String(formData.login_activity)}
            list="login-activity-options"
            onChange={(e) => onFieldChange('login_activity', e.target.value)}
            required
          />
          <Input
            placeholder="cpu_usage"
            value={String(formData.cpu_usage)}
            list="cpu-usage-options"
            onChange={(e) => onFieldChange('cpu_usage', e.target.value)}
            required
          />
          <Input
            placeholder="network_traffic"
            value={String(formData.network_traffic)}
            list="network-traffic-options"
            onChange={(e) => onFieldChange('network_traffic', e.target.value)}
            required
          />
          <Input
            placeholder="file_changes"
            value={String(formData.file_changes)}
            list="file-change-options"
            onChange={(e) => onFieldChange('file_changes', e.target.value)}
            required
          />
          <Input
            placeholder="user_behavior"
            value={String(formData.user_behavior)}
            list="user-behavior-options"
            onChange={(e) => onFieldChange('user_behavior', e.target.value)}
            required
          />
          <datalist id="login-activity-options">
            {loginOptions.map((option) => (
              <option key={option} value={option} />
            ))}
          </datalist>
          <datalist id="cpu-usage-options">
            {cpuOptions.map((option) => (
              <option key={option} value={option} />
            ))}
          </datalist>
          <datalist id="network-traffic-options">
            {networkOptions.map((option) => (
              <option key={option} value={option} />
            ))}
          </datalist>
          <datalist id="file-change-options">
            {fileChangeOptions.map((option) => (
              <option key={option} value={option} />
            ))}
          </datalist>
          <datalist id="user-behavior-options">
            {userBehaviorOptions.map((option) => (
              <option key={option} value={option} />
            ))}
          </datalist>
          <div className="md:col-span-3 flex items-center gap-3">
            <Button type="submit" disabled={isSubmitting} className="gap-2">
              <Send className="w-4 h-4" />
              {isSubmitting ? 'Submitting...' : 'Submit Telemetry'}
            </Button>
            <Button type="button" variant="destructive" disabled={isClearing} onClick={onClearTelemetry}>
              {isClearing ? 'Clearing...' : 'Clear Telemetry'}
            </Button>
            {statusMessage ? <span className="text-xs text-muted-foreground">{statusMessage}</span> : null}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
