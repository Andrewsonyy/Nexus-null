'use client';

import { useEffect, useMemo, useState } from 'react';
import { Radar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api, type BlindspotAnalysis } from '@/lib/api';

type Dot = { x: number; y: number };

const fallbackAnalysis: BlindspotAnalysis = {
  observed: 0,
  inferred_gaps: 0,
  blind_spot_risks: 0,
};

function createDots(count: number, radius: number, phase: number): Dot[] {
  if (count <= 0) {
    return [];
  }

  const safeCount = Math.min(count, 24);
  return Array.from({ length: safeCount }, (_, index) => {
    const angle = phase + (index * Math.PI * 2) / safeCount;
    const wobble = (index % 3) * 3;
    const x = 150 + Math.cos(angle) * (radius + wobble);
    const y = 100 + Math.sin(angle) * (radius + wobble);
    return { x, y };
  });
}

export function UnknownUnknownDetection() {
  const [analysis, setAnalysis] = useState<BlindspotAnalysis>(fallbackAnalysis);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await api.blindspotAnalysis();
        setAnalysis(data);
      } catch {
        setAnalysis(fallbackAnalysis);
      }
    };

    load();
    const interval = setInterval(load, 3000);
    const onTelemetryUpdate = () => {
      void load();
    };
    window.addEventListener('telemetry-updated', onTelemetryUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onTelemetryUpdate);
    };
  }, []);

  const observedDots = useMemo(() => createDots(analysis.observed, 58, -Math.PI / 2), [analysis.observed]);
  const inferredDots = useMemo(() => createDots(analysis.inferred_gaps, 38, -Math.PI / 4), [analysis.inferred_gaps]);
  const riskDots = useMemo(() => createDots(analysis.blind_spot_risks, 75, Math.PI / 3), [analysis.blind_spot_risks]);

  return (
    <Card className="border-border bg-card/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Radar className="w-5 h-5 text-accent" />
          Unknown Unknown Detection
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="w-full aspect-video bg-secondary/50 rounded-lg border border-border flex items-center justify-center overflow-hidden">
          <svg viewBox="0 0 300 200" className="w-full h-full text-accent opacity-70">
            <circle cx="150" cy="100" r="20" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3" />
            <circle cx="150" cy="100" r="40" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3" />
            <circle cx="150" cy="100" r="60" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3" />
            <circle cx="150" cy="100" r="80" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3" />

            <line x1="150" y1="20" x2="150" y2="180" stroke="currentColor" strokeWidth="0.5" opacity="0.2" />
            <line x1="70" y1="100" x2="230" y2="100" stroke="currentColor" strokeWidth="0.5" opacity="0.2" />
            <line x1="90" y1="38" x2="210" y2="162" stroke="currentColor" strokeWidth="0.5" opacity="0.2" />
            <line x1="210" y1="38" x2="90" y2="162" stroke="currentColor" strokeWidth="0.5" opacity="0.2" />

            <g style={{ transformOrigin: '150px 100px' }} className="animate-[spin_8s_linear_infinite]">
              <line x1="150" y1="100" x2="228" y2="100" stroke="#22d3ee" strokeWidth="1.2" opacity="0.65" />
            </g>

            {observedDots.map((dot, i) => (
              <circle key={`o-${i}`} cx={dot.x} cy={dot.y} r="3" fill="#10b981" />
            ))}
            {inferredDots.map((dot, i) => (
              <circle key={`i-${i}`} cx={dot.x} cy={dot.y} r="2.6" fill="#f59e0b" />
            ))}
            {riskDots.map((dot, i) => (
              <circle key={`r-${i}`} cx={dot.x} cy={dot.y} r="2.2" fill="#ef4444" />
            ))}

            <text x="160" y="20" fontSize="10" fill="currentColor" opacity="0.6" textAnchor="middle">
              Observed
            </text>
            <text x="240" y="105" fontSize="10" fill="currentColor" opacity="0.6" textAnchor="start">
              Inferred
            </text>
            <text x="150" y="190" fontSize="10" fill="currentColor" opacity="0.6" textAnchor="middle">
              Blind Spots
            </text>
          </svg>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="p-3 bg-secondary/50 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-xs font-semibold text-foreground">Observed</span>
            </div>
            <div className="text-2xl font-bold text-green-500">{analysis.observed}</div>
          </div>
          <div className="p-3 bg-secondary/50 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span className="text-xs font-semibold text-foreground">Inferred</span>
            </div>
            <div className="text-2xl font-bold text-yellow-500">{analysis.inferred_gaps}</div>
          </div>
          <div className="p-3 bg-secondary/50 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-xs font-semibold text-foreground">Risk</span>
            </div>
            <div className="text-2xl font-bold text-red-500">{analysis.blind_spot_risks}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
