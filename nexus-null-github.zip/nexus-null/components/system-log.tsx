'use client';

import { useEffect, useState } from 'react';
import { Terminal } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api, type SystemLogEntry } from '@/lib/api';

const fallbackLogs: SystemLogEntry[] = [
  { time: '--:--', type: 'warning', message: 'Backend unavailable. Showing placeholder logs.' },
];

const colors: Record<SystemLogEntry['type'], string> = {
  success: 'text-green-400',
  warning: 'text-yellow-400',
  error: 'text-red-400',
  info: 'text-blue-400',
  status: 'text-cyan-400',
};

export function SystemLog() {
  const [logEntries, setLogEntries] = useState<SystemLogEntry[]>(fallbackLogs);

  useEffect(() => {
    const load = async () => {
      try {
        setLogEntries(await api.systemLogs());
      } catch {
        setLogEntries(fallbackLogs);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    const onTelemetryUpdate = () => {
      void load();
    };
    window.addEventListener('telemetry-updated', onTelemetryUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onTelemetryUpdate);
    };
  }, []);

  return (
    <Card className="border-border bg-card/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Terminal className="w-5 h-5 text-accent" />
          System Event Log
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="bg-secondary/50 rounded-lg border border-border p-4 font-mono text-xs max-h-64 overflow-y-auto space-y-2">
          {logEntries.map((entry, i) => (
            <div key={`${entry.time}-${i}`} className={colors[entry.type]}>
              <span className="text-muted-foreground">[{entry.time}]</span> {entry.message}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
