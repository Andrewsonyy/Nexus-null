'use client';

import { useEffect, useState, type ComponentType } from 'react';
import { Activity, Eye, Network, Radio, ShieldAlert, User, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { api, type DecisionStatus, type EpistemicMetrics, type SignalStatus } from '@/lib/api';

type SignalItem = { name: string; status: SignalStatus };

const iconBySignal: Record<string, ComponentType<{ className?: string }>> = {
  'Login Activity': Eye,
  'CPU Usage': Zap,
  'CPU Load': Zap,
  'Network Traffic': Network,
  'File Modification': ShieldAlert,
  'User Behavior': User,
};

const statusDotClass: Record<SignalStatus, string> = {
  available: 'bg-green-500',
  partial: 'bg-yellow-500',
  missing: 'bg-red-500',
};

const fallbackSignals: SignalItem[] = [
  { name: 'Login Activity', status: 'available' },
  { name: 'CPU Usage', status: 'partial' },
  { name: 'Network Traffic', status: 'partial' },
  { name: 'File Modification', status: 'available' },
  { name: 'User Behavior', status: 'partial' },
];

const fallbackMetrics: EpistemicMetrics = {
  known_variables: 2,
  known_unknowns: 3,
  blind_spots: 0,
  completeness: 40,
  uncertainty: 60,
  risk: 0,
};

const fallbackDecision: DecisionStatus = {
  status: 'blocked',
  action: 'refuse_attack_detection',
  reason: 'Insufficient telemetry for safe threat detection.',
  confidence: 0,
  threshold: 70,
  missing_variables: [],
  investigation_questions: [],
  investigation_analysis: {
    answered_questions: 0,
    total_questions: 0,
    coverage: 100,
    conclusive_answers: 0,
    sufficient_for_prediction: false,
    risk_adjustment: 0,
    insights: ['No investigation questions required.'],
    unresolved_questions: [],
  },
  threat_assessment: {
    classification: 'benign',
    risk_level: 'low',
    risk_score: 0,
    confidence: 0,
    reasons: ['No suspicious indicators detected from provided security fields'],
  },
  final_prediction: {
    status: 'pending_investigation',
    label: 'PENDING INVESTIGATION',
    risk_score: 0,
    confidence: 0,
    reason: 'Insufficient telemetry for safe threat detection.',
    method: 'deferred',
  },
};

export function DashboardGrid() {
  const [signals, setSignals] = useState<SignalItem[]>(fallbackSignals);
  const [metrics, setMetrics] = useState<EpistemicMetrics>(fallbackMetrics);
  const [decision, setDecision] = useState<DecisionStatus>(fallbackDecision);

  useEffect(() => {
    const normalizeDecision = (decisionData: Partial<DecisionStatus>): DecisionStatus => ({
      ...fallbackDecision,
      ...decisionData,
      threat_assessment: decisionData.threat_assessment ?? fallbackDecision.threat_assessment,
      final_prediction: decisionData.final_prediction ?? fallbackDecision.final_prediction,
      investigation_analysis: decisionData.investigation_analysis ?? fallbackDecision.investigation_analysis,
      missing_variables: decisionData.missing_variables ?? [],
      investigation_questions: decisionData.investigation_questions ?? [],
    });

    const load = async () => {
      try {
        const [signalsData, metricsData, decisionData] = await Promise.all([
          api.signals(),
          api.epistemicMetrics(),
          api.decisionStatus(),
        ]);
        setSignals(signalsData.signals);
        setMetrics(metricsData);
        setDecision(normalizeDecision(decisionData));
      } catch {
        setSignals(fallbackSignals);
        setMetrics(fallbackMetrics);
        setDecision(fallbackDecision);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    const onTelemetryUpdate = () => {
      void load();
    };
    window.addEventListener('telemetry-updated', onTelemetryUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onTelemetryUpdate);
    };
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <Radio className="w-5 h-5 text-accent" />
          Observed Signals
        </h2>
        <div className="space-y-3">
          {signals.map((signal) => {
            const Icon = iconBySignal[signal.name] ?? Activity;
            return (
              <Card key={signal.name} className="border-border bg-card/50 backdrop-blur-sm hover:bg-card/70 transition-colors">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5 text-accent" />
                    <span className="text-sm font-medium text-foreground">{signal.name}</span>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${statusDotClass[signal.status]} animate-pulse`}></div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <Zap className="w-5 h-5 text-accent" />
          Epistemic Reasoning Core
        </h2>

        <div className="space-y-3">
          <Card className="border-border bg-card/50 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Known Variables</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{metrics.known_variables}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card/50 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Known Unknowns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-500">{metrics.known_unknowns}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card/50 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Potential Blind Spots</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{metrics.blind_spots}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card/50 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Epistemic Completeness</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-2">
                  <span>Known</span>
                  <span className="text-primary">{metrics.completeness}%</span>
                </div>
                <Progress value={metrics.completeness} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-xs mb-2">
                  <span>Unknown</span>
                  <span className="text-yellow-500">{metrics.uncertainty}%</span>
                </div>
                <Progress value={metrics.uncertainty} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-xs mb-2">
                  <span>Blind Spot Risk</span>
                  <span className="text-red-500">{metrics.risk}%</span>
                </div>
                <Progress value={metrics.risk} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <Activity className="w-5 h-5 text-accent" />
          Decision Safety and Threat Risk
        </h2>

        <Card className={`border-border bg-card/50 backdrop-blur-sm ${decision.status === 'blocked' ? 'border-red-500/30' : 'border-green-500/30'}`}>
          <CardHeader>
            <CardTitle className="text-base">Decision Gate (Epistemic)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <div className={`w-4 h-4 rounded-full animate-pulse ${decision.status === 'blocked' ? 'bg-red-500' : 'bg-green-500'}`}></div>
              <span className={`text-lg font-semibold ${decision.status === 'blocked' ? 'text-red-500' : 'text-green-500'}`}>
                {decision.status.toUpperCase()}
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              {decision.reason}
            </div>
          </CardContent>
        </Card>

        <Card
          className={`border-border bg-card/50 backdrop-blur-sm ${
            decision.threat_assessment.classification === 'malicious'
              ? 'border-red-500/30'
              : decision.threat_assessment.classification === 'suspicious'
                ? 'border-yellow-500/30'
                : 'border-green-500/30'
          }`}
        >
          <CardHeader>
            <CardTitle className="text-base">Threat Assessment (Security Risk)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div
              className={`text-lg font-semibold ${
                decision.threat_assessment.classification === 'malicious'
                  ? 'text-red-500'
                  : decision.threat_assessment.classification === 'suspicious'
                    ? 'text-yellow-500'
                    : 'text-green-500'
              }`}
            >
              {decision.threat_assessment.classification.toUpperCase()}
            </div>
            <div className="text-sm text-muted-foreground">
              Risk score: {decision.threat_assessment.risk_score}% | Level: {decision.threat_assessment.risk_level.toUpperCase()}
            </div>
            <Progress value={decision.threat_assessment.risk_score} className="h-2" />
            <div className="text-xs text-muted-foreground">
              Coverage confidence: {decision.threat_assessment.confidence}%
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card/50 backdrop-blur-sm border-cyan-500/30">
          <CardHeader>
            <CardTitle className="text-base">Final Output Prediction</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-lg font-semibold text-cyan-400">{decision.final_prediction.label}</div>
            <div className="text-sm text-muted-foreground">{decision.final_prediction.reason}</div>
            <div className="text-xs text-muted-foreground">
              Final risk: {decision.final_prediction.risk_score}% | Confidence: {decision.final_prediction.confidence}%
            </div>
            <div className="text-xs text-muted-foreground">Prediction method: {decision.final_prediction.method}</div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-base">Confidence Score</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-3xl font-bold text-primary">{decision.confidence}%</div>
            <Progress value={decision.confidence} className="h-3" />
            <div className="text-xs text-muted-foreground">Safety threshold: {decision.threshold}%</div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-base">Threat Indicators</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {decision.threat_assessment.reasons.length === 0 ? (
              <span className="text-sm text-green-500">No suspicious indicators detected.</span>
            ) : (
              decision.threat_assessment.reasons.map((reason) => (
                <div key={reason} className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm text-foreground">{reason}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-base">Investigation Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-xs text-muted-foreground">
              Answered: {decision.investigation_analysis.answered_questions}/{decision.investigation_analysis.total_questions} | Coverage:{' '}
              {decision.investigation_analysis.coverage}% | Risk adjustment: {decision.investigation_analysis.risk_adjustment > 0 ? '+' : ''}
              {decision.investigation_analysis.risk_adjustment}
            </div>
            {decision.investigation_questions.length === 0 ? (
              <span className="text-sm text-green-500">No blind-spot follow-up questions required.</span>
            ) : (
              decision.investigation_questions.map((question) => (
                <div key={question} className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full mt-1.5"></div>
                  <span className="text-sm text-foreground">{question}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
