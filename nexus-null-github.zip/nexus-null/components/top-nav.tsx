'use client';

import { Clock } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api, type SystemStatus } from '@/lib/api';

export function TopNav() {
  const [time, setTime] = useState<string>('');
  const [status, setStatus] = useState<SystemStatus | null>(null);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const loadStatus = async () => {
      try {
        const data = await api.systemStatus();
        setStatus(data);
      } catch {
        setStatus(null);
      }
    };

    loadStatus();
    const interval = setInterval(loadStatus, 10000);
    const onTelemetryUpdate = () => {
      void loadStatus();
    };
    window.addEventListener('telemetry-updated', onTelemetryUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener('telemetry-updated', onTelemetryUpdate);
    };
  }, []);

  return (
    <nav className="border-b border-border bg-secondary/30 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-accent rounded-full"></div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">NEXUS-NULL++</h1>
          <span className="text-xs text-muted-foreground ml-2">Pre-Epistemic AI Decision System</span>
        </div>
        
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full animate-pulse ${status?.system === 'online' ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="text-sm text-muted-foreground">
              {status?.system === 'online' ? 'Online / Monitoring' : 'Offline / No backend'}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full animate-pulse ${status?.ai_engine === 'active' ? 'bg-blue-500' : 'bg-gray-500'}`}></div>
            <span className="text-sm text-muted-foreground">
              {status?.ai_engine === 'active' ? 'AI Engine Active' : 'AI Engine Inactive'}
            </span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{time || '--:--:--'}</span>
          </div>
        </div>
      </div>
    </nav>
  );
}
