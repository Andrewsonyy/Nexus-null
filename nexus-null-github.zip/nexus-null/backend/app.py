from __future__ import annotations

import re
import os
from datetime import datetime
from pathlib import Path
from typing import Any

import joblib
import networkx as nx
import pandas as pd
from sklearn.linear_model import LogisticRegression
from fastapi import FastAPI
from fastapi import HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="NEXUS-NULL++ API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SAFE_THRESHOLD = 0.70

SIGNAL_LABELS = {
    "login_activity": "Login Activity",
    "cpu_usage": "CPU Usage",
    "network_traffic": "Network Traffic",
    "file_changes": "File Modification",
    "user_behavior": "User Behavior",
}

REQUIRED_SIGNALS = [
    "login_activity",
    "cpu_usage",
    "network_traffic",
    "file_changes",
]

SAMPLE_TELEMETRY = [
    {
        "time": "10:00",
        "login_activity": 5,
        "cpu_usage": "?",
        "network_traffic": "High",
        "file_changes": "Normal",
        "user_behavior": "Normal",
    },
    {
        "time": "10:05",
        "login_activity": 1,
        "cpu_usage": "High",
        "network_traffic": "?",
        "file_changes": "Normal",
        "user_behavior": "?",
    },
    {
        "time": "10:10",
        "login_activity": 10,
        "cpu_usage": "?",
        "network_traffic": "?",
        "file_changes": "Modified",
        "user_behavior": "Anomalous",
    },
]


class SignalItem(BaseModel):
    name: str
    status: str


class LogEntry(BaseModel):
    time: str
    type: str
    message: str


class TelemetryRecord(BaseModel):
    time: str
    login_activity: Any
    cpu_usage: Any
    network_traffic: Any
    file_changes: Any
    user_behavior: Any


class InvestigationAnswer(BaseModel):
    question: str
    answer: str


class InvestigationAnswerBatch(BaseModel):
    answers: list[InvestigationAnswer]


TELEMETRY_RECORDS: list[dict[str, Any]] = []
INVESTIGATION_ANSWERS: dict[str, str] = {}
FALLBACK_MODEL: LogisticRegression | None = None
EXTERNAL_MODEL: Any | None = None
EXTERNAL_MODEL_FEATURES: list[str] = []
EXTERNAL_MODEL_LOAD_ERROR: str | None = None
RESOLVED_MODEL_PATH: Path | None = None


def _model_path_candidates() -> list[Path]:
    configured_path = os.getenv("INTRUSION_MODEL_PATH", "").strip()
    candidates: list[Path] = []
    if configured_path:
        candidates.append(Path(configured_path))
    candidates.append(Path(__file__).resolve().parents[1] / "model" / "intrusion_detection_model.pkl")
    candidates.append(Path(r"C:\Users\mazin\Downloads\archive\intrusion_detection_model.pkl"))
    return candidates


def _resolve_model_path() -> Path | None:
    for path in _model_path_candidates():
        if path.exists():
            return path
    return None


class ModelPredictionRequest(BaseModel):
    features: dict[str, Any]


class BatchModelPredictionRequest(BaseModel):
    rows: list[dict[str, Any]]


def _to_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        cleaned = value.strip()
        if cleaned in {"", "?"}:
            return None
        try:
            return float(cleaned)
        except ValueError:
            return None
    return None


def _signal_status(value: Any) -> str:
    if value is None:
        return "missing"
    if isinstance(value, str) and value.strip() in {"", "?"}:
        return "missing"
    return "available"


def _validate_record(record: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for signal in SIGNAL_LABELS:
        result[signal] = _signal_status(record.get(signal))
    return result


def _aggregate_signal_states(records: list[dict[str, Any]]) -> dict[str, str]:
    if not records:
        return {signal: "missing" for signal in SIGNAL_LABELS}

    per_record = [_validate_record(record) for record in records]
    aggregated: dict[str, str] = {}
    for signal in SIGNAL_LABELS:
        statuses = [row[signal] for row in per_record]
        if all(status == "available" for status in statuses):
            aggregated[signal] = "available"
        elif all(status == "missing" for status in statuses):
            aggregated[signal] = "missing"
        else:
            aggregated[signal] = "partial"
    return aggregated


def _blind_spot_detection(signal_states: dict[str, str]) -> tuple[list[str], float]:
    missing_required = [signal for signal in REQUIRED_SIGNALS if signal_states[signal] != "available"]
    severity = len(missing_required) / len(REQUIRED_SIGNALS)
    return missing_required, severity


def _dependency_analysis(signal_states: dict[str, str]) -> list[str]:
    graph = nx.DiGraph()
    graph.add_node("intrusion_detection")
    for signal in REQUIRED_SIGNALS:
        graph.add_edge(signal, "intrusion_detection")

    violations: list[str] = []
    for source, _target in graph.edges:
        if signal_states.get(source) != "available":
            violations.append(source)
    return violations


def _generate_questions(signal_states: dict[str, str], record: dict[str, Any] | None) -> list[str]:
    blind_spots_exist = any(status != "available" for status in signal_states.values())
    if not blind_spots_exist:
        return []

    questions: list[str] = []

    def add_question(question: str) -> None:
        if question not in questions:
            questions.append(question)

    generic_by_signal = {
        "login_activity": "What was the login activity during the event window?",
        "cpu_usage": "What was the CPU utilization during the event?",
        "network_traffic": "Was abnormal network traffic observed during the event?",
        "file_changes": "Were critical files modified during the event?",
        "user_behavior": "Were privileged accounts used during the event?",
    }

    for signal, status in signal_states.items():
        if status != "available":
            add_question(generic_by_signal[signal])

    login_value = _to_float(record.get("login_activity")) if record else None
    network_value = str(record.get("network_traffic", "")).strip().lower() if record else ""
    file_value = str(record.get("file_changes", "")).strip().lower() if record else ""
    user_value = str(record.get("user_behavior", "")).strip().lower() if record else ""

    suspicious_network = network_value in {"high", "spike", "anomalous", "suspicious", "exfiltration_like", "exfiltration"}
    suspicious_file_changes = file_value in {"modified", "mass_modified", "encrypted", "deleted", "tampered", "suspicious"}
    suspicious_user_behavior = user_value in {
        "anomalous",
        "abnormal_access",
        "privilege_escalation",
        "impossible_travel",
        "lateral_movement",
        "suspicious",
    }

    if signal_states["cpu_usage"] != "available" and login_value is not None and login_value >= 20:
        add_question("What was the CPU utilization during the login spike?")
    if signal_states["network_traffic"] != "available" and (login_value is not None and login_value >= 20):
        add_question("Was abnormal outbound traffic observed during the login spike?")
    if signal_states["network_traffic"] != "available" and suspicious_file_changes:
        add_question("Did outbound traffic increase while suspicious file changes occurred?")
    if signal_states["user_behavior"] != "available" and (suspicious_network or suspicious_file_changes):
        add_question("Were privileged accounts or unusual admin sessions active during this event?")
    if signal_states["file_changes"] != "available" and suspicious_user_behavior:
        add_question("Which files were accessed or modified by the anomalous user sessions?")
    if signal_states["login_activity"] != "available" and suspicious_network:
        add_question("Were there failed login bursts from the same sources as anomalous network traffic?")

    if len(questions) < 3:
        add_question("What additional telemetry sources can validate or refute this threat hypothesis?")

    return questions


def _decision_readiness(signal_states: dict[str, str], dependency_violations: list[str]) -> float:
    total_signals = len(SIGNAL_LABELS)
    available_signals = sum(1 for status in signal_states.values() if status == "available")
    signal_completeness = available_signals / total_signals

    total_dependencies = len(REQUIRED_SIGNALS)
    satisfied_dependencies = total_dependencies - len(dependency_violations)
    dependency_score = satisfied_dependencies / total_dependencies

    return (signal_completeness * 0.6) + (dependency_score * 0.4)


def _decision_gatekeeper(readiness: float, missing_required: list[str]) -> dict[str, Any]:
    if readiness >= SAFE_THRESHOLD:
        return {
            "status": "allowed",
            "action": "allow_attack_detection",
            "reason": "Telemetry completeness is sufficient for safe threat detection.",
            "missing_signals": [SIGNAL_LABELS[signal] for signal in missing_required],
        }

    return {
        "status": "blocked",
        "action": "refuse_attack_detection",
        "reason": "Insufficient telemetry for safe threat detection.",
        "missing_signals": [SIGNAL_LABELS[signal] for signal in missing_required],
    }


def _categorical_suspicion(value: Any, suspicious_terms: set[str]) -> int:
    text = str(value or "").strip().lower()
    return 1 if text in suspicious_terms else 0


def _feature_vector(record: dict[str, Any] | None, signal_states: dict[str, str], threat_score: int, readiness: float) -> list[float]:
    if record is None:
        return [0.0, 0.0, 0.0, 0.0, 0.0, 5.0, float(threat_score), float(readiness)]

    login = _to_float(record.get("login_activity"))
    cpu = _to_float(record.get("cpu_usage"))

    login_norm = (login or 0.0) / 60.0
    cpu_norm = (cpu or 0.0) / 100.0
    network_flag = _categorical_suspicion(
        record.get("network_traffic"),
        {"high", "spike", "anomalous", "suspicious", "exfiltration_like", "exfiltration"},
    )
    file_flag = _categorical_suspicion(
        record.get("file_changes"),
        {"modified", "mass_modified", "encrypted", "deleted", "tampered", "suspicious"},
    )
    user_flag = _categorical_suspicion(
        record.get("user_behavior"),
        {"anomalous", "abnormal_access", "privilege_escalation", "impossible_travel", "lateral_movement", "suspicious"},
    )
    missing_count = sum(1 for status in signal_states.values() if status != "available")

    return [
        login_norm,
        cpu_norm,
        float(network_flag),
        float(file_flag),
        float(user_flag),
        float(missing_count),
        float(threat_score),
        float(readiness),
    ]


def _load_external_model() -> tuple[Any | None, list[str]]:
    global EXTERNAL_MODEL
    global EXTERNAL_MODEL_FEATURES
    global EXTERNAL_MODEL_LOAD_ERROR
    global RESOLVED_MODEL_PATH

    if EXTERNAL_MODEL is not None:
        return EXTERNAL_MODEL, EXTERNAL_MODEL_FEATURES
    if EXTERNAL_MODEL_LOAD_ERROR is not None:
        return None, []

    model_path = _resolve_model_path()
    if model_path is None:
        EXTERNAL_MODEL_LOAD_ERROR = (
            "Model file not found. Checked: "
            + ", ".join(str(path) for path in _model_path_candidates())
        )
        return None, []
    RESOLVED_MODEL_PATH = model_path

    try:
        model = joblib.load(model_path)
    except Exception as exc:
        EXTERNAL_MODEL_LOAD_ERROR = f"Failed to load model from {model_path}: {exc}"
        return None, []

    feature_names = getattr(model, "feature_names_in_", None)
    if feature_names is None:
        n_features = int(getattr(model, "n_features_in_", 0))
        feature_names = [f"feature_{idx}" for idx in range(n_features)]

    EXTERNAL_MODEL = model
    if hasattr(EXTERNAL_MODEL, "n_jobs"):
        EXTERNAL_MODEL.n_jobs = 1
    EXTERNAL_MODEL_FEATURES = [str(name) for name in feature_names]
    return EXTERNAL_MODEL, EXTERNAL_MODEL_FEATURES


def _vector_from_feature_map(features: dict[str, Any], expected_features: list[str]) -> tuple[list[float] | None, list[str], list[str]]:
    missing: list[str] = []
    invalid: list[str] = []
    vector: list[float] = []

    for feature_name in expected_features:
        raw_value = features.get(feature_name)
        numeric_value = _to_float(raw_value)
        if raw_value is None:
            missing.append(feature_name)
            vector.append(0.0)
            continue
        if numeric_value is None:
            invalid.append(feature_name)
            vector.append(0.0)
            continue
        vector.append(float(numeric_value))

    if missing or invalid:
        return None, missing, invalid
    return vector, [], []


def _predict_with_external_model(features: dict[str, Any]) -> dict[str, Any]:
    model, expected_features = _load_external_model()
    if model is None:
        return {
            "ok": False,
            "error": EXTERNAL_MODEL_LOAD_ERROR or "External model unavailable.",
        }

    vector, missing, invalid = _vector_from_feature_map(features, expected_features)
    if vector is None:
        return {
            "ok": False,
            "error": "Invalid or incomplete feature payload.",
            "missing_features": missing,
            "invalid_features": invalid,
            "expected_feature_count": len(expected_features),
            "provided_feature_count": len(features),
        }

    if not hasattr(model, "predict_proba"):
        return {
            "ok": False,
            "error": "Loaded model does not support probability predictions.",
        }

    payload_frame = pd.DataFrame([vector], columns=expected_features)
    probability = float(model.predict_proba(payload_frame)[0][1])
    risk_score = int(round(probability * 100))
    predicted_label = int(model.predict(payload_frame)[0])
    status = "attack_likely" if risk_score >= 70 else ("no_attack_indicated" if risk_score <= 30 else "suspicious_needs_review")

    return {
        "ok": True,
        "status": status,
        "risk_score": risk_score,
        "predicted_label": predicted_label,
        "attack_probability": probability,
        "expected_feature_count": len(expected_features),
    }


def _get_fallback_model() -> LogisticRegression:
    global FALLBACK_MODEL
    if FALLBACK_MODEL is not None:
        return FALLBACK_MODEL

    # Synthetic training data for fallback classification when evidence is incomplete.
    x_train = [
        [0.03, 0.30, 0, 0, 0, 0, 8, 1.00],
        [0.05, 0.35, 0, 0, 0, 0, 12, 1.00],
        [0.08, 0.40, 0, 0, 0, 1, 18, 0.82],
        [0.10, 0.45, 0, 0, 0, 2, 24, 0.68],
        [0.20, 0.65, 1, 0, 0, 1, 42, 0.82],
        [0.28, 0.80, 1, 1, 0, 1, 58, 0.82],
        [0.35, 0.90, 1, 1, 1, 0, 84, 1.00],
        [0.50, 0.95, 1, 1, 1, 0, 95, 1.00],
        [0.42, 0.88, 1, 1, 1, 2, 88, 0.68],
        [0.30, 0.70, 1, 0, 1, 3, 55, 0.54],
        [0.02, 0.25, 0, 0, 0, 4, 5, 0.20],
        [0.15, 0.55, 0, 0, 0, 2, 28, 0.54],
    ]
    y_train = [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0]

    model = LogisticRegression(random_state=42, max_iter=500)
    model.fit(x_train, y_train)
    FALLBACK_MODEL = model
    return model


def _ml_fallback_prediction(record: dict[str, Any] | None, signal_states: dict[str, str], threat_score: int, readiness: float) -> dict[str, Any]:
    if record:
        external_result = _predict_with_external_model(record)
        if external_result.get("ok"):
            risk_score = int(external_result["risk_score"])
            if risk_score >= 70:
                return {
                    "status": "attack_likely",
                    "label": "ATTACK LIKELY",
                    "risk_score": risk_score,
                    "reason": "Integrated RandomForest model indicates high attack likelihood.",
                }
            if risk_score <= 30:
                return {
                    "status": "no_attack_indicated",
                    "label": "NO ATTACK INDICATED",
                    "risk_score": risk_score,
                    "reason": "Integrated RandomForest model indicates low attack likelihood.",
                }
            return {
                "status": "suspicious_needs_review",
                "label": "SUSPICIOUS - NEEDS REVIEW",
                "risk_score": risk_score,
                "reason": "Integrated RandomForest model indicates uncertain risk; analyst review is required.",
            }

    model = _get_fallback_model()
    features = _feature_vector(record, signal_states, threat_score, readiness)
    attack_probability = float(model.predict_proba([features])[0][1])
    risk_score = int(round(attack_probability * 100))

    if risk_score >= 70:
        return {
            "status": "attack_likely",
            "label": "ATTACK LIKELY",
            "risk_score": risk_score,
            "reason": "Fallback ML model indicates high attack likelihood from incomplete telemetry and weak investigation evidence.",
        }
    if risk_score <= 30:
        return {
            "status": "no_attack_indicated",
            "label": "NO ATTACK INDICATED",
            "risk_score": risk_score,
            "reason": "Fallback ML model indicates low attack likelihood from available evidence.",
        }
    return {
        "status": "suspicious_needs_review",
        "label": "SUSPICIOUS - NEEDS REVIEW",
        "risk_score": risk_score,
        "reason": "Fallback ML model indicates uncertain risk; analyst review is required.",
    }


def _extract_first_number(text: str) -> float | None:
    match = re.search(r"[-+]?\d*\.?\d+", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _score_single_answer(question: str, answer: str) -> tuple[int, str]:
    text = answer.strip().lower()
    if not text:
        return 0, "No answer provided"

    suspicious_terms = {
        "yes",
        "high",
        "spike",
        "anomalous",
        "suspicious",
        "privileged",
        "admin",
        "modified",
        "encrypted",
        "exfiltration",
        "failed",
    }
    benign_terms = {"no", "normal", "baseline", "stable", "none", "benign"}
    uncertain_terms = {"unknown", "not sure", "n/a", "unclear", "pending"}

    for term in uncertain_terms:
        if term in text:
            return 0, "Answer is inconclusive"

    score = 0
    reason = "No strong signal from answer"
    q = question.lower()
    value = _extract_first_number(text)

    if "cpu" in q and value is not None:
        if value >= 85:
            return 15, f"Answer indicates high CPU ({value:.0f}%)"
        if value <= 60:
            return -10, f"Answer indicates normal CPU ({value:.0f}%)"
    if "login" in q and value is not None:
        if value >= 20:
            return 14, f"Answer indicates high login count ({value:.0f})"
        if value <= 5:
            return -10, f"Answer indicates low login count ({value:.0f})"

    if any(term in text for term in suspicious_terms):
        score += 10
        reason = "Answer supports suspicious activity"
    if any(term in text for term in benign_terms):
        score -= 8
        reason = "Answer supports benign activity"

    return score, reason


def _analyze_investigation_answers(questions: list[str]) -> dict[str, Any]:
    total_questions = len(questions)
    if total_questions == 0:
        return {
            "answered_questions": 0,
            "total_questions": 0,
            "coverage": 100,
            "risk_adjustment": 0,
            "insights": ["No investigation questions required."],
            "unresolved_questions": [],
        }

    answered = 0
    conclusive_answers = 0
    risk_adjustment = 0
    insights: list[str] = []
    unresolved_questions: list[str] = []

    for question in questions:
        answer = INVESTIGATION_ANSWERS.get(question, "").strip()
        if not answer:
            unresolved_questions.append(question)
            continue
        answered += 1
        delta, reason = _score_single_answer(question, answer)
        risk_adjustment += delta
        if delta != 0:
            conclusive_answers += 1
        insights.append(f"{reason}: {question}")

    risk_adjustment = max(-35, min(35, risk_adjustment))
    coverage = int((answered / total_questions) * 100)
    sufficiency = coverage == 100 and (conclusive_answers > 0 or abs(risk_adjustment) >= 10)
    if not insights:
        insights.append("No answered investigation inputs available yet.")

    return {
        "answered_questions": answered,
        "total_questions": total_questions,
        "coverage": coverage,
        "conclusive_answers": conclusive_answers,
        "sufficient_for_prediction": sufficiency,
        "risk_adjustment": risk_adjustment,
        "insights": insights,
        "unresolved_questions": unresolved_questions,
    }


def _final_prediction(
    gatekeeper: dict[str, Any],
    threat: dict[str, Any],
    investigation: dict[str, Any],
    signal_states: dict[str, str],
    record: dict[str, Any] | None,
    readiness: float,
) -> dict[str, Any]:
    blind_spots_exist = any(status != "available" for status in signal_states.values())
    if blind_spots_exist and investigation["answered_questions"] < investigation["total_questions"]:
        return {
            "status": "pending_investigation",
            "label": "PENDING INVESTIGATION",
            "risk_score": threat["risk_score"],
            "confidence": 0,
            "reason": "Prediction deferred: answer all investigation questions before generating output.",
            "method": "deferred",
        }

    adjusted_risk = max(0, min(100, threat["risk_score"] + investigation["risk_adjustment"]))
    combined_confidence = int((threat["confidence"] * 0.65) + (investigation["coverage"] * 0.35))

    if blind_spots_exist and not investigation["sufficient_for_prediction"]:
        ml_result = _ml_fallback_prediction(record, signal_states, adjusted_risk, readiness)
        return {
            **ml_result,
            "confidence": combined_confidence,
            "method": "ml_fallback",
        }

    if gatekeeper["status"] == "blocked":
        return {
            "status": "refused",
            "label": "REFUSED",
            "risk_score": adjusted_risk,
            "confidence": combined_confidence,
            "reason": "Insufficient telemetry for safe threat detection.",
            "method": "rule_based",
        }

    if adjusted_risk >= 70:
        status = "attack_likely"
        label = "ATTACK LIKELY"
        reason = "Combined telemetry and investigation responses indicate likely malicious activity."
    elif adjusted_risk <= 30:
        status = "no_attack_indicated"
        label = "NO ATTACK INDICATED"
        reason = "Combined telemetry and investigation responses do not indicate active malicious behavior."
    else:
        status = "suspicious_needs_review"
        label = "SUSPICIOUS - NEEDS REVIEW"
        reason = "Signals are mixed; analyst review is required before final action."

    return {
        "status": status,
        "label": label,
        "risk_score": adjusted_risk,
        "confidence": combined_confidence,
        "reason": reason,
        "method": "rule_based",
    }


def _threat_assessment(record: dict[str, Any] | None, signal_states: dict[str, str]) -> dict[str, Any]:
    if record is None:
        return {
            "classification": "benign",
            "risk_level": "low",
            "risk_score": 0,
            "confidence": 0,
            "reasons": ["No telemetry records available for threat assessment"],
        }

    score = 0
    reasons: list[str] = []

    login_value = _to_float(record.get("login_activity"))
    if login_value is not None:
        if login_value >= 40:
            score += 25
            reasons.append("Extreme login volume detected")
        elif login_value >= 20:
            score += 18
            reasons.append("High login activity detected")
        elif login_value >= 10:
            score += 8
            reasons.append("Elevated login activity detected")

    cpu_value = _to_float(record.get("cpu_usage"))
    if cpu_value is not None:
        if cpu_value >= 90:
            score += 20
            reasons.append("Critical CPU utilization observed")
        elif cpu_value >= 80:
            score += 14
            reasons.append("High CPU utilization observed")
        elif cpu_value >= 70:
            score += 8
            reasons.append("Elevated CPU utilization observed")

    network_value = str(record.get("network_traffic", "")).strip().lower()
    suspicious_network = network_value in {
        "high",
        "spike",
        "anomalous",
        "suspicious",
        "exfiltration_like",
        "exfiltration",
    }
    if suspicious_network:
        score += 20
        reasons.append("Suspicious network traffic pattern detected")

    file_value = str(record.get("file_changes", "")).strip().lower()
    suspicious_file_changes = file_value in {
        "modified",
        "mass_modified",
        "encrypted",
        "deleted",
        "tampered",
        "suspicious",
    }
    if suspicious_file_changes:
        score += 20
        reasons.append("Suspicious file system changes detected")

    user_value = str(record.get("user_behavior", "")).strip().lower()
    suspicious_user_behavior = user_value in {
        "anomalous",
        "abnormal_access",
        "privilege_escalation",
        "impossible_travel",
        "lateral_movement",
        "suspicious",
    }
    if suspicious_user_behavior:
        score += 20
        reasons.append("Anomalous user behavior detected")

    if login_value is not None and login_value >= 20 and suspicious_network and suspicious_file_changes:
        score += 10
        reasons.append("Correlated attack pattern across login, network, and file telemetry")

    if suspicious_user_behavior and suspicious_file_changes:
        score += 5
        reasons.append("User-behavior and file-change correlation indicates elevated attack likelihood")

    score = min(score, 100)
    if score >= 70:
        level = "high"
        classification = "malicious"
    elif score >= 40:
        level = "medium"
        classification = "suspicious"
    else:
        level = "low"
        classification = "benign"

    field_coverage = sum(1 for status in signal_states.values() if status == "available") / len(signal_states)
    confidence = int(field_coverage * 100)

    return {
        "classification": classification,
        "risk_level": level,
        "risk_score": score,
        "confidence": confidence,
        "reasons": reasons if reasons else ["No suspicious indicators detected from provided security fields"],
    }


def _build_log_entries(
    signal_states: dict[str, str],
    missing_required: list[str],
    readiness: float,
    gatekeeper: dict[str, Any],
    threat_assessment: dict[str, Any],
    final_prediction: dict[str, Any],
) -> list[LogEntry]:
    now = datetime.now()
    entries: list[LogEntry] = []
    for signal, status in signal_states.items():
        label = SIGNAL_LABELS[signal]
        if status == "missing":
            entries.append(
                LogEntry(
                    time=now.strftime("%H:%M"),
                    type="warning",
                    message=f"Telemetry missing: {label}",
                )
            )
        elif status == "partial":
            entries.append(
                LogEntry(
                    time=now.strftime("%H:%M"),
                    type="info",
                    message=f"Telemetry partial: {label}",
                )
            )

    if missing_required:
        entries.append(
            LogEntry(
                time=now.strftime("%H:%M"),
                type="error",
                message=f"Dependency violation(s): {', '.join(SIGNAL_LABELS[s] for s in missing_required)}",
            )
        )

    entries.append(
        LogEntry(
            time=now.strftime("%H:%M"),
            type="status",
            message=f"Decision {gatekeeper['status'].upper()} at readiness {int(readiness * 100)}%",
        )
    )
    if gatekeeper["status"] == "blocked":
        entries.append(
            LogEntry(
                time=now.strftime("%H:%M"),
                type="error",
                message=gatekeeper["reason"],
            )
        )
    entries.append(
        LogEntry(
            time=now.strftime("%H:%M"),
            type="status",
            message=(
                f"Threat assessment {threat_assessment['classification'].upper()} "
                f"(risk {threat_assessment['risk_score']}%)"
            ),
        )
    )
    entries.append(
        LogEntry(
            time=now.strftime("%H:%M"),
            type="status",
            message=(
                f"Final prediction {final_prediction['label']} "
                f"(risk {final_prediction['risk_score']}%, confidence {final_prediction['confidence']}%, method {final_prediction['method']})"
            ),
        )
    )
    return entries


def _run_pipeline() -> dict[str, Any]:
    records = TELEMETRY_RECORDS
    signal_states = _aggregate_signal_states(records)
    missing_required, blind_spot_severity = _blind_spot_detection(signal_states)
    dependency_violations = _dependency_analysis(signal_states)
    readiness = _decision_readiness(signal_states, dependency_violations)
    gatekeeper = _decision_gatekeeper(readiness, missing_required)
    latest_record = records[-1] if records else None
    threat = _threat_assessment(latest_record, signal_states)
    questions = _generate_questions(signal_states, latest_record)
    investigation = _analyze_investigation_answers(questions)
    final_prediction = _final_prediction(gatekeeper, threat, investigation, signal_states, latest_record, readiness)
    logs = _build_log_entries(signal_states, missing_required, readiness, gatekeeper, threat, final_prediction)

    known_variables = sum(1 for status in signal_states.values() if status == "available")
    known_unknowns = sum(1 for status in signal_states.values() if status == "partial")
    blind_spots = sum(1 for status in signal_states.values() if status == "missing")
    uncertainty = int((known_unknowns / len(signal_states)) * 100)

    return {
        "system_status": {
            "system": "online",
            "ai_engine": "active",
            "timestamp": datetime.now().strftime("%H:%M:%S"),
        },
        "signals": [
            SignalItem(name=SIGNAL_LABELS[signal], status=status).model_dump()
            for signal, status in signal_states.items()
        ],
        "epistemic_metrics": {
            "known_variables": known_variables,
            "known_unknowns": known_unknowns,
            "blind_spots": blind_spots,
            "completeness": int((known_variables / len(signal_states)) * 100),
            "uncertainty": uncertainty,
            "risk": int(blind_spot_severity * 100),
        },
        "decision_status": {
            "status": gatekeeper["status"],
            "action": gatekeeper["action"],
            "reason": gatekeeper["reason"],
            "confidence": int(readiness * 100),
            "threshold": int(SAFE_THRESHOLD * 100),
            "missing_variables": gatekeeper["missing_signals"],
            "investigation_questions": questions,
            "investigation_analysis": investigation,
            "threat_assessment": threat,
            "final_prediction": final_prediction,
        },
        "blindspot_analysis": {
            "observed": known_variables,
            "inferred_gaps": known_unknowns,
            "blind_spot_risks": len(dependency_violations),
        },
        "system_logs": [entry.model_dump() for entry in logs],
    }


@app.on_event("startup")
def warmup_external_model() -> None:
    _load_external_model()


@app.get("/api/system-status")
def get_system_status() -> dict[str, Any]:
    return _run_pipeline()["system_status"]


@app.get("/api/telemetry")
def get_telemetry() -> dict[str, Any]:
    return {"records": TELEMETRY_RECORDS}


@app.post("/api/telemetry")
def add_telemetry(record: TelemetryRecord) -> dict[str, Any]:
    TELEMETRY_RECORDS.append(record.model_dump())
    return {"status": "ok", "records_count": len(TELEMETRY_RECORDS)}


@app.delete("/api/telemetry")
def clear_telemetry() -> dict[str, Any]:
    cleared_telemetry = len(TELEMETRY_RECORDS)
    cleared_answers = len(INVESTIGATION_ANSWERS)
    TELEMETRY_RECORDS.clear()
    INVESTIGATION_ANSWERS.clear()
    return {
        "status": "cleared",
        "records_count": 0,
        "cleared_telemetry_records": cleared_telemetry,
        "cleared_investigation_answers": cleared_answers,
    }


@app.get("/api/model-info")
def get_model_info() -> dict[str, Any]:
    model, feature_names = _load_external_model()
    if model is None:
        return {
            "loaded": False,
            "path": str(_resolve_model_path() or ""),
            "checked_paths": [str(path) for path in _model_path_candidates()],
            "error": EXTERNAL_MODEL_LOAD_ERROR,
        }

    return {
        "loaded": True,
        "path": str(RESOLVED_MODEL_PATH) if RESOLVED_MODEL_PATH else "",
        "model_type": type(model).__name__,
        "feature_count": len(feature_names),
        "feature_names": feature_names,
    }


@app.post("/api/model-predict")
def model_predict(payload: ModelPredictionRequest) -> dict[str, Any]:
    prediction = _predict_with_external_model(payload.features)
    if not prediction.get("ok"):
        raise HTTPException(status_code=400, detail=prediction)
    return prediction


@app.post("/api/model-predict/batch")
def model_predict_batch(payload: BatchModelPredictionRequest) -> dict[str, Any]:
    if not payload.rows:
        raise HTTPException(status_code=400, detail="rows must not be empty")

    outputs: list[dict[str, Any]] = []
    for idx, row in enumerate(payload.rows):
        prediction = _predict_with_external_model(row)
        if not prediction.get("ok"):
            raise HTTPException(status_code=400, detail={"row_index": idx, **prediction})
        outputs.append(prediction)

    return {"count": len(outputs), "predictions": outputs}


@app.get("/api/investigation-answers")
def get_investigation_answers() -> dict[str, Any]:
    return {"answers": INVESTIGATION_ANSWERS}


@app.post("/api/investigation-answers")
def submit_investigation_answers(payload: InvestigationAnswerBatch) -> dict[str, Any]:
    for item in payload.answers:
        INVESTIGATION_ANSWERS[item.question] = item.answer
    return {"status": "ok", "saved_answers": len(payload.answers)}


@app.delete("/api/investigation-answers")
def clear_investigation_answers() -> dict[str, Any]:
    INVESTIGATION_ANSWERS.clear()
    return {"status": "cleared"}


@app.get("/api/signals")
def get_signals() -> dict[str, Any]:
    return {"signals": _run_pipeline()["signals"]}


@app.get("/api/epistemic-metrics")
def get_epistemic_metrics() -> dict[str, Any]:
    return _run_pipeline()["epistemic_metrics"]


@app.get("/api/decision-status")
def get_decision_status() -> dict[str, Any]:
    return _run_pipeline()["decision_status"]


@app.get("/api/blindspot-analysis")
def get_blindspot_analysis() -> dict[str, Any]:
    return _run_pipeline()["blindspot_analysis"]


@app.get("/api/system-logs")
def get_system_logs() -> list[dict[str, Any]]:
    return _run_pipeline()["system_logs"]
