import { TopNav } from '@/components/top-nav';
import { DashboardGrid } from '@/components/dashboard-grid';
import { ExplanationPanel } from '@/components/explanation-panel';
import { UnknownUnknownDetection } from '@/components/unknown-unknown-detection';
import { SystemLog } from '@/components/system-log';
import { TelemetryInputPanel } from '@/components/telemetry-input-panel';
import { InvestigationResponsePanel } from '@/components/investigation-response-panel';

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <TopNav />
      <main className="container mx-auto px-6 py-8 space-y-6">
        <TelemetryInputPanel />
        <DashboardGrid />
        <ExplanationPanel />
        <InvestigationResponsePanel />
        <UnknownUnknownDetection />
        <SystemLog />
      </main>
    </div>
  );
}
